<?php

namespace Commercers\Coupons\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Checkout\Model\Cart\RequestQuantityProcessor;
use Magento\Framework\ObjectManagerInterface;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var ObjectManagerInterface
     */
    protected $_objectManager;
    /**
     * @var \Magento\Checkout\Model\Cart
     */
    protected $_cart;
    /**
     * @var RequestQuantityProcessor
     */
    protected $quantityProcessor;

    public function __construct(
        Context $context,
        \Magento\Checkout\Model\Cart $cart,
        ObjectManagerInterface $objectManager,
        RequestQuantityProcessor $quantityProcessor = null
    )
    {
        parent::__construct($context);
        $this->_cart = $cart;
        $this->_objectManager = $objectManager;
        $this->quantityProcessor = $quantityProcessor ?: $this->_objectManager->get(RequestQuantityProcessor::class);
    }

    public function getStoreConfigValue($path, $storeId = null)
    {
        return $this->scopeConfig->getValue($path, \Magento\Store\Model\ScopeInterface::SCOPE_STORE, $storeId);
    }
    public function cancelCouponAfter(){
        $quote = $this->_cart->getQuote();
        $items = $quote->getAllItems();
        $cartData = array();
        foreach ($items as $item){
            $cartData[$item->getId()] = array(
                'qty' => (string)$item->getQty()
            );
        }
        if(is_array($cartData)){
            if (!$this->_cart->getCustomerSession()->getCustomerId() && $this->_cart->getQuote()->getCustomerId()) {
                $this->_cart->getQuote()->setCustomerId(null);
            }
            $cartData = $this->quantityProcessor->process($cartData);
            $cartData = $this->_cart->suggestItemsQty($cartData);
            $this->_cart->updateItems($cartData)->save();
        }
    }
}
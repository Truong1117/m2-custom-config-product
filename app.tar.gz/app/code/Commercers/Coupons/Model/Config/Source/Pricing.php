<?php

namespace Commercers\Coupons\Model\Config\Source;

use Commercers\Coupons\Model\Constant;

class Pricing implements \Magento\Framework\Option\ArrayInterface
{
    public function toOptionArray()
    {
        return [
            [
                'value' => Constant::COMMERCERS_COUPONS_PRICING_VALUE_WEBSITE,
                'label' => __('Website'),
            ],
            [
                'value' => Constant::COMMERCERS_COUPONS_PRICING_VALUE_FINAL_PRICE,
                'label' => __('Final Price'),
            ]
        ];
    }
}
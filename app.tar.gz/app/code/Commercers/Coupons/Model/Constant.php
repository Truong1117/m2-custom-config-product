<?php

namespace Commercers\Coupons\Model;

class Constant
{
    const COMMERCERS_COUPONS_CONFIG_ENABLE = 'commercers_coupons/general/enable';
    const COMMERCERS_COUPONS_CONFIG_MULTIPLE = 'commercers_coupons/general/multiple';
    const COMMERCERS_COUPONS_CONFIG_PRICING = 'commercers_coupons/general/pricing';

    const COMMERCERS_COUPONS_PRICING_VALUE_WEBSITE = 'website';
    const COMMERCERS_COUPONS_PRICING_VALUE_FINAL_PRICE = 'final_price';
}
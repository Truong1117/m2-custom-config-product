<?php

namespace Commercers\Coupons\Model\Override\SalesRule\Model;

use Magento\Quote\Model\Quote\Address;
use Magento\Quote\Model\Quote\Item\AbstractItem;
use Magento\SalesRule\Helper\CartFixedDiscount;
use Magento\SalesRule\Model\ResourceModel\Rule\CollectionFactory;
use Commercers\Coupons\Model\Constant;

class Validator extends \Magento\SalesRule\Model\Validator
{
    protected $_couponsHelperData;
    protected $_cart;

    public function __construct(
        \Magento\Framework\Model\Context                        $context,
        \Magento\Framework\Registry                             $registry,
        CollectionFactory                                       $collectionFactory,
        \Magento\Catalog\Helper\Data                            $catalogData,
        \Magento\SalesRule\Model\Utility                        $utility,
        \Magento\SalesRule\Model\RulesApplier                   $rulesApplier,
        \Magento\Framework\Pricing\PriceCurrencyInterface       $priceCurrency,
        \Magento\SalesRule\Model\Validator\Pool                 $validators,
        \Magento\Framework\Message\ManagerInterface             $messageManager,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb           $resourceCollection = null,
        array                                                   $data = [],
        CartFixedDiscount                                       $cartFixedDiscount = null,
        \Commercers\Coupons\Helper\Data                         $couponsHelperData,
        \Magento\Checkout\Model\Cart                            $cart
    )
    {
        parent::__construct($context, $registry, $collectionFactory, $catalogData, $utility, $rulesApplier, $priceCurrency, $validators, $messageManager, $resource, $resourceCollection, $data, $cartFixedDiscount);
        $this->_couponsHelperData = $couponsHelperData;
        $this->_cart = $cart;
    }


    /**
     * Return item price
     *
     * @param AbstractItem $item
     * @return float
     */
    public function getItemPrice($item)
    {
        $_pricing = $this->_couponsHelperData->getStoreConfigValue(Constant::COMMERCERS_COUPONS_CONFIG_PRICING);
        if ($this->_couponsHelperData->getStoreConfigValue(Constant::COMMERCERS_COUPONS_CONFIG_ENABLE)
            && $_pricing == Constant::COMMERCERS_COUPONS_PRICING_VALUE_WEBSITE
            && $this->getCouponCode()) {
            $this->_changeItemPrice($item->getId(), $this->getItemOriginalPrice($item));
            return $this->getItemOriginalPrice($item);
        } else {
            $this->_changeItemPrice($item->getId(), null);
            return parent::getItemPrice($item);
        }

    }

    protected function _changeItemPrice($itemId, $itemPrice)
    {
        $quote = $this->_cart->getQuote();
        $_quoteItem = $quote->getItemById($itemId);
        $_quoteItem->setCustomPrice($itemPrice);
        $_quoteItem->setOriginalCustomPrice($itemPrice);

    }
}
<?php

namespace Commercers\Coupons\Model\Override\SalesRule\Model\ResourceModel;

class Coupon extends \Magento\SalesRule\Model\ResourceModel\Coupon
{
    protected function _construct()
    {
        $this->_init('salesrule_coupon', 'coupon_id');
    }
}
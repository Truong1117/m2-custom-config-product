<?php

namespace Commercers\Coupons\Model\Override\Checkout\Controller\Cart;

use Commercers\Coupons\Model\Constant;
use Magento\Checkout\Model\Cart\RequestQuantityProcessor;

class CouponPost extends \Magento\Checkout\Controller\Cart\CouponPost
{
    protected $_couponsHelperData;
    private $quantityProcessor;

    public function __construct(
        \Magento\Framework\App\Action\Context              $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Checkout\Model\Session                    $checkoutSession,
        \Magento\Store\Model\StoreManagerInterface         $storeManager,
        \Magento\Framework\Data\Form\FormKey\Validator     $formKeyValidator,
        \Magento\Checkout\Model\Cart                       $cart,
        \Magento\SalesRule\Model\CouponFactory             $couponFactory,
        \Magento\Quote\Api\CartRepositoryInterface         $quoteRepository,
        RequestQuantityProcessor                           $quantityProcessor = null,
        \Commercers\Coupons\Helper\Data                    $couponsHelperData
    )
    {
        parent::__construct($context, $scopeConfig, $checkoutSession, $storeManager, $formKeyValidator, $cart, $couponFactory, $quoteRepository);
        $this->_couponsHelperData = $couponsHelperData;
        $this->quantityProcessor = $quantityProcessor ?: $this->_objectManager->get(RequestQuantityProcessor::class);
    }

    public function execute()
    {
        $couponCode = $this->getRequest()->getParam('remove') == 1
            ? ''
            : trim($this->getRequest()->getParam('coupon_code'));

        $cartQuote = $this->cart->getQuote();
        $oldCouponCode = $cartQuote->getCouponCode();

        $codeLength = strlen($couponCode);
        if (!$codeLength && !strlen($oldCouponCode)) {
            return $this->_goBack();
        }

        try {
            $isCodeLengthValid = $codeLength && $codeLength <= \Magento\Checkout\Helper\Cart::COUPON_CODE_MAX_LENGTH;

            $itemsCount = $cartQuote->getItemsCount();
            if ($itemsCount) {
                //custom
                if ($this->_couponsHelperData->getStoreConfigValue(Constant::COMMERCERS_COUPONS_CONFIG_ENABLE) && $codeLength) {

                    $_pricing = $this->_couponsHelperData->getStoreConfigValue(Constant::COMMERCERS_COUPONS_CONFIG_PRICING);
                    foreach ($this->cart->getQuote()->getAllItems() as $item) {
                        /**
                         * @var $item \Magento\Quote\Model\Quote\Item
                         */
                        if ($_pricing == Constant::COMMERCERS_COUPONS_PRICING_VALUE_WEBSITE) {
                            $regularPrice = $item->getProduct()->getPriceInfo()->getPrice('regular_price')->getValue();
                            $item->setCustomPrice($regularPrice);
                            $item->setOriginalCustomPrice($regularPrice);
                        }

                    }
                }
                //custom
                $cartQuote->getShippingAddress()->setCollectShippingRates(true);
                $cartQuote->setCouponCode($isCodeLengthValid ? $couponCode : '')->collectTotals();
                $this->quoteRepository->save($cartQuote);
            }

            if ($codeLength) {
                $escaper = $this->_objectManager->get(\Magento\Framework\Escaper::class);
                $coupon = $this->couponFactory->create();
                $coupon->load($couponCode, 'code');
                if (!$itemsCount) {
                    if ($isCodeLengthValid && $coupon->getId()) {
                        $this->_checkoutSession->getQuote()->setCouponCode($couponCode)->save();
                        $this->messageManager->addSuccessMessage(
                            __(
                                'You used coupon code "%1".',
                                $escaper->escapeHtml($couponCode)
                            )
                        );
                    } else {
                        $this->messageManager->addErrorMessage(
                            __(
                                'The coupon code "%1" is not valid.',
                                $escaper->escapeHtml($couponCode)
                            )
                        );
                    }
                } else {
                    if ($isCodeLengthValid && $coupon->getId() && $couponCode == $cartQuote->getCouponCode()) {
                        $this->messageManager->addSuccessMessage(
                            __(
                                'You used coupon code "%1".',
                                $escaper->escapeHtml($couponCode)
                            )
                        );
                    } else {
                        $this->messageManager->addErrorMessage(
                            __(
                                'The coupon code "%1" is not valid.',
                                $escaper->escapeHtml($couponCode)
                            )
                        );
                    }
                }


            } else {
                //Custom

                $items = $this->cart->getItems();
                $_productIds = array();
                foreach ($this->cart->getQuote()->getAllItems() as $item) {
                    /**
                     * @var $item \Magento\Quote\Model\Quote\Item
                     */
                    $item->setData('custom_price', null);
                    $item->setData('original_custom_price', null);
                }
                $this->cart->getQuote()->setTotalsCollectedFlag(false);
                $this->cart->save();

                $this->messageManager->addSuccessMessage(__('You canceled the coupon code.'));
            }
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__('We cannot apply the coupon code.'));
            $this->_objectManager->get(\Psr\Log\LoggerInterface::class)->critical($e);
        }

        return $this->_goBack();
    }

}